<?php
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "hpdb";

    $conn = mysqli_connect($hostname, $username, $password, $dbname)
?>